
# KM-24 SE Team 12 Repository

Created for Team 12 - Section Medan




## Team Members

This project is worked by following members:

- Ridzky Putra Dwitama
- Audric Lowell
- Khaerina Fadillah
- Adelia Putri Handayani
- Putu Sintha 
- Riza Reka Atin
- Ayub Fahri
- Muhammad Farhan
- Nuuri Hafida
- Fahruddin Hisannurijal
- Yenni Luthfi
- Tiara Carendra Galih

